package Owner;




import javax.swing.*;
import java.awt.*;



public class OwnerPanel {

    public static void ShowMenu()  {

        JFrame ownerframe = new JFrame("Owner Panel");
        ownerframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        //set menu
        JMenuBar ownermenu = new JMenuBar();
        JMenu manage=new JMenu("manage");
        JMenuItem manageprofile = new JMenuItem("manage profile");
        JMenuItem managebooking = new JMenuItem("manage booking");
        ownermenu.add(manage);
        manage.add(manageprofile);
        manage.add(managebooking);

        //set search panel


        //set main panel
        JPanel mainPanel = new JPanel();
        ownerframe.setJMenuBar(ownermenu);
        ownerframe.pack();
        ownerframe.setVisible(true);
        ownerframe.setExtendedState(JFrame.MAXIMIZED_BOTH);

    }



    public static void main(String[] args) {
        ShowMenu();
    }

}

