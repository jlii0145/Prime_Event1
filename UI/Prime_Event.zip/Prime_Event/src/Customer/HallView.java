package Customer;

public class HallView {
}
