package Customer;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.io.IOException;


public class CustomerPanel {

    public static void ShowMenu()  {

        JFrame customerframe = new JFrame("Hall Menu");
        JSplitPane splitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT);
        splitPane.setDividerLocation(30);
        customerframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        //set menu
        JMenuBar customermenu = new JMenuBar();
        JMenu manage=new JMenu("manage");
        JMenuItem manageprofile = new JMenuItem("manage profile");
        JMenuItem managebooking = new JMenuItem("manage booking");
        customermenu.add(manage);
        manage.add(manageprofile);
        manage.add(managebooking);

        //set search panel
        JPanel searchPanel = new JPanel();
        searchPanel.setBounds(0,0,10000,30);
        searchPanel.setBackground(Color.gray);

        searchPanel.setLayout(null);
        JLabel datelabel = new JLabel("Date:");
        datelabel.setBounds(10,5,50,20);
        JLabel tolabel = new JLabel("To");
        tolabel.setBounds(310,5,50,20);
        JLabel namelabel = new JLabel("Name:");
        namelabel.setBounds(610,5,50,20);

        JTextField dateText1 = new JTextField(10);
        dateText1.setBounds(110,5,170,20);
        JTextField dateText2 = new JTextField(10);
        dateText2.setBounds(410,5,170,20);
        JTextField nameText = new JTextField(10);
        nameText.setBounds(710,5,130,20);

        JButton searchButton = new JButton("search");
        searchButton.setBounds(900,5,130,20);
        searchPanel.add(datelabel);
        searchPanel.add(tolabel);
        searchPanel.add(namelabel);

        searchPanel.add(dateText1);
        searchPanel.add(dateText2);
        searchPanel.add(nameText);

        searchPanel.add( searchButton);

        //set main panel
       JPanel mainPanel = new JPanel();


        //gridLayout
     /*   GridLayout gridLayout = new GridLayout(3,3,3,3);
        mainPanel.setLayout(gridLayout);*/


        //add buttons
     /*   JButton resultButton = new JButton();
        String[] hallname = {"1","2","3","4","5","6"};

      for(int i = 0; i < hallname.length; i++) {
          ImageIcon image = new ImageIcon("E:\\"+hallname[i]+".jpg");
            JButton jb = new JButton(hallname[i],image);
            //jb.setIconTextGap(2);
           *//* jb.setHorizontalTextPosition(JButton.RIGHT);
            jb.setVerticalTextPosition(JButton.CENTER);*//*
           *//* jb.setIcon(image);
            jb.setName(string);*//*
            mainPanel.add(jb);
        }*/
        //config resultButton

      /*  resultButton.setIcon(image);
      resultButton.setSize(200, 50);
        resultButton.setHorizontalAlignment(SwingConstants.RIGHT);
        resultButton.setEnabled(false);
        mainPanel.add(resultButton);*/
        //setSize(250,200);

        splitPane.setTopComponent(searchPanel);
        splitPane.setBottomComponent(new HallTable().js);
        customerframe.add(splitPane);
        customerframe.setJMenuBar(customermenu);
        customerframe.pack();
        customerframe.setVisible(true);
        customerframe.setExtendedState(JFrame.MAXIMIZED_BOTH);
       // customerframe.add(new HallTable().halltable);

    }



    public static void main(String[] args) {
        ShowMenu();
    }

}

