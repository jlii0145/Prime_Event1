package Administrator;


import javax.swing.*;
import java.awt.*;



public class AdministratorPanel {

    public static void ShowMenu()  {

        JFrame administratorframe = new JFrame("Administrator Panel");
        administratorframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        //set menu
        JMenuBar administratormenu = new JMenuBar();
        JMenu manage=new JMenu("manage");
        JMenuItem manageprofile = new JMenuItem("manage profile");
        JMenuItem managebooking = new JMenuItem("manage booking");
        administratormenu.add(manage);
        manage.add(manageprofile);
        manage.add(managebooking);

        //set search panel
      
       
        //set main panel
        JPanel mainPanel = new JPanel();
        administratorframe.setJMenuBar(administratormenu);
        administratorframe.pack();
        administratorframe.setVisible(true);
        administratorframe.setExtendedState(JFrame.MAXIMIZED_BOTH);

    }



    public static void main(String[] args) {
        ShowMenu();
    }

}


