import Administrator.AdministratorPanel;
import Customer.CustomerPanel;
import Owner.OwnerPanel;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class LoginPanel{
    private static JDialog logindialog;
    public static void main(String[] args) {
        ShowLogin();
    }
    public static void ShowLogin()
    {

        logindialog = new JDialog();
        logindialog.setTitle("Login Panel");
        logindialog.setSize(350, 200);


        JPanel loginpanel = new JPanel();

        logindialog.add(loginpanel);
        placeComponents(loginpanel);
        logindialog.setVisible(true);

//set the location of logindialog in the center of screen
        Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
        int w = logindialog.getSize().width;
        int h = logindialog.getSize().height;
        int x = (dim.width-w)/2;
        int y = (dim.height-h)/2;
        logindialog.setLocation(x, y-100);

    }
    private static void placeComponents(JPanel loginpanel) {

        loginpanel.setLayout(null);

        JLabel userLabel = new JLabel("E-mail:");
        userLabel.setBounds(30,30,80,25);
        loginpanel.add(userLabel);


        JTextField userText = new JTextField(20);
        userText.setBounds(130,30,165,25);
        loginpanel.add(userText);

        JLabel passwordLabel = new JLabel("Password:");
        passwordLabel.setBounds(30,60,80,25);
        loginpanel.add(passwordLabel);

        JPasswordField passwordText = new JPasswordField(20);
        passwordText.setBounds(130,60,165,25);
        loginpanel.add(passwordText);

        //set combobox
        JLabel ActorLabel= new JLabel("Actor:");
        ActorLabel.setBounds(30,90,80,25);
        loginpanel.add(ActorLabel);
        JComboBox ActorComboBox = new JComboBox();
        ActorComboBox.setBounds(130,90,165,25);
        ActorComboBox.addItem("Please Choose");
        ActorComboBox.addItem("Customer");
        ActorComboBox.addItem("Owner");
        ActorComboBox.addItem("Administrator");
        loginpanel.add(ActorComboBox);

        JButton loginButton = new JButton("login");
        loginButton.setBounds(70, 120, 80, 25);
        loginpanel.add(loginButton);

        JButton signupButton = new JButton("sign up");
        signupButton.setBounds(180, 120, 80, 25);
        loginpanel.add(signupButton);

        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String selectedItem =  ActorComboBox.getSelectedItem().toString();
                if(selectedItem.equals("Customer"))
                {
                    CustomerPanel.ShowMenu();
                    logindialog.setVisible(false);
                }else if(selectedItem.equals("Owner"))
                {
                    OwnerPanel.ShowMenu();
                    logindialog.setVisible(false);
                }else if(selectedItem.equals("Administrator"))
                {
                    AdministratorPanel.ShowMenu();
                    logindialog.setVisible(false);
                }



            }
        });
        signupButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                RegisterPanel.showRegister();
                logindialog.setVisible(false);
            }
        });
    }






}