package Owner;




import Login_and_Register.LoginPanel;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;


public class OwnerPanel {

    public static void ShowMenu()  {

        JFrame ownerframe = new JFrame("Owner Panel");
        ownerframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        //set menu
        JMenuBar ownermenu = new JMenuBar();
        JMenu manage=new JMenu("manage");
        JMenuItem manageprofile = new JMenuItem("manage profile");
        JMenuItem managebooking = new JMenuItem("manage booking");
        ownermenu.add(manage);
        manage.add(manageprofile);
        manage.add(managebooking);

        JMenu logout = new JMenu("Log out");
        ownermenu.add(logout);
        logout.addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {
                ownerframe.setVisible(false);
                LoginPanel login = new LoginPanel();
                login.logindialog.setVisible(true);
            }

            @Override
            public void mousePressed(MouseEvent e) {

            }

            @Override
            public void mouseReleased(MouseEvent e) {

            }

            @Override
            public void mouseEntered(MouseEvent e) {

            }

            @Override
            public void mouseExited(MouseEvent e) {

            }
        });


        //set main panel
        Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
        int width = dim.getSize().width;
        int height = dim.getSize().height;
        int w = 150;
        int h = 60;
        int x = (width-w)/2;
        int y = (height-h)-130;

        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(null);
        //table
        Object[] columnNames = {"Hall Name","Address","Capacity","Price","Desciption"};
        Object[][] rowData = {
                {"Test1", "111", 80, 100,"aaa"},
                {"Test2", "111", 80, 120,"bbb"},
                {"Test3", "111", 70, 130,"ccc"},
        };
        DefaultTableModel tablemodel = new DefaultTableModel(rowData,columnNames);
        JTable ownerhalltable = new JTable(tablemodel);
        JScrollPane jsp = new JScrollPane(ownerhalltable);
        jsp.setBounds(0,0,width,500);
        //button

        JButton createhall = new JButton("Create");
        createhall.setBounds(x-100,y,w,h);
        createhall.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JDialog createdialog = new JDialog();
                createdialog.setTitle("Create Hall");
                createdialog.setSize(350,350);
                JPanel createpanel = new JPanel();
                createpanel.setLayout(null);

                JLabel NameLabel = new JLabel("Hall Name:");
                NameLabel.setBounds(70,30,110,25);
                createpanel.add(NameLabel);

                JTextField NameText = new JTextField();
                NameText.setBounds(180,30,110,25);
                createpanel.add(NameText);

                JLabel AddLabel = new JLabel("Address:");
                AddLabel.setBounds(70,80,80,25);
                createpanel.add(AddLabel);

                JTextField AddText = new JTextField();
                AddText.setBounds(180,80,110,25);
                createpanel.add(AddText);


                JLabel CapacityLabel = new JLabel("Capacity:");
                CapacityLabel.setBounds(70,130,110,25);
                createpanel.add(CapacityLabel);

                JTextField CapacityText = new JTextField();
                CapacityText.setBounds(180,130,110,25);
                createpanel.add(CapacityText);

                JLabel PriceLabel = new JLabel("Price:");
                PriceLabel.setBounds(70,180,110,25);
                createpanel.add(PriceLabel);

                JTextField PriceText = new JTextField();
                PriceText.setBounds(180,180,110,25);
                createpanel.add(PriceText);

                JLabel DesLabel = new JLabel("Description:");
                DesLabel.setBounds(70,230,80,25);
                createpanel.add(DesLabel);

                JTextArea DesText = new JTextArea();
                DesText.setBounds(180,230,110,45);
                createpanel.add(DesText);

                JButton confirm= new JButton("Confirm");
                confirm.setBounds(120,280,90,25);




                confirm.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        createdialog.setVisible(false);
                        //add function
                        Object[] Hallinformation = {NameText.getText(),AddText.getText(),CapacityText.getText(),PriceText.getText(),DesText.getText()};
                        tablemodel.addRow(Hallinformation);
                        DesText.getText();
                        JOptionPane.showMessageDialog(createdialog, "create successful!");
                    }
                });



                createpanel.add(confirm);
                createdialog.add(createpanel);
                Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
                int w =  createdialog.getSize().width;
                int h =  createdialog.getSize().height;
                int x = (dim.width-w)/2;
                int y = (dim.height-h)/2;
                createdialog.setLocation(x, y-100);
                createdialog.setVisible(true);


            }
        });
        JButton edithall = new JButton("Edit");
        edithall.setBounds(x+100,y,w,h);
        edithall.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedrow = ownerhalltable.getSelectedRow();
                JDialog editdialog = new JDialog();
                editdialog.setTitle("Edit Hall");
                editdialog.setSize(350,350);
                JPanel editpanel = new JPanel();
                editpanel.setLayout(null);

                JLabel NameLabel = new JLabel("Hall Name:");
                NameLabel.setBounds(70,30,110,25);
                editpanel.add(NameLabel);


                JTextField NameText = new JTextField();
                NameText.setBounds(180,30,110,25);
                NameText.setText(ownerhalltable.getValueAt(selectedrow,0).toString());
                editpanel.add(NameText);

                JLabel AddLabel = new JLabel("Address:");
                AddLabel.setBounds(70,80,80,25);
                editpanel.add(AddLabel);

                JTextField AddText = new JTextField();
                AddText.setBounds(180,80,110,25);
                AddText.setText(ownerhalltable.getValueAt(selectedrow,1).toString());
                editpanel.add(AddText);


                JLabel CapacityLabel = new JLabel("Capacity:");
                CapacityLabel.setBounds(70,130,110,25);
                editpanel.add(CapacityLabel);

                JTextField CapacityText = new JTextField();
                CapacityText.setBounds(180,130,110,25);
                CapacityText.setText(ownerhalltable.getValueAt(selectedrow,2).toString());
                editpanel.add(CapacityText);

                JLabel PriceLabel = new JLabel("Price:");
                PriceLabel.setBounds(70,180,110,25);
                editpanel.add(PriceLabel);

                JTextField PriceText = new JTextField();
                PriceText.setBounds(180,180,110,25);
                PriceText.setText(ownerhalltable.getValueAt(selectedrow,3).toString());
                editpanel.add(PriceText);

                JLabel DesLabel = new JLabel("Description:");
                DesLabel.setBounds(70,230,80,25);
                editpanel.add(DesLabel);

                JTextArea DesText = new JTextArea();
                DesText.setBounds(180,230,110,45);
                DesText.setText(ownerhalltable.getValueAt(selectedrow,4).toString());
                editpanel.add(DesText);

                JButton confirm= new JButton("Confirm");
                confirm.setBounds(120,280,90,25);




                confirm.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        editdialog.setVisible(false);
                        //add function
                        tablemodel.setValueAt(NameText.getText(),selectedrow,0);
                        tablemodel.setValueAt(AddText.getText(),selectedrow,1);
                        tablemodel.setValueAt(CapacityText.getText(),selectedrow,2);
                        tablemodel.setValueAt(PriceText.getText(),selectedrow,3);
                        tablemodel.setValueAt(DesText.getText(),selectedrow,4);
                        DesText.getText();
                        JOptionPane.showMessageDialog(editdialog, "edit successful!");
                    }
                });



                editpanel.add(confirm);
                editdialog.add(editpanel);
                Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
                int w =  editdialog.getSize().width;
                int h =  editdialog.getSize().height;
                int x = (dim.width-w)/2;
                int y = (dim.height-h)/2;
                editdialog.setLocation(x, y-100);
                editdialog.setVisible(true);

            }
        });
        mainPanel.add(jsp);
        mainPanel.add(createhall);
        mainPanel.add(edithall);
        ownerframe.setJMenuBar(ownermenu);
        ownerframe.add(mainPanel);
        ownerframe.pack();
        ownerframe.setVisible(true);
        ownerframe.setExtendedState(JFrame.MAXIMIZED_BOTH);

    }



    public static void main(String[] args) {
        ShowMenu();
    }

}

