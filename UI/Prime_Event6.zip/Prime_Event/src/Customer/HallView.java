package Customer;

import org.w3c.dom.events.Event;

import javax.imageio.ImageIO;
import javax.naming.Name;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.File;

public class HallView {
    public static JFrame hallviewframe;
    String hallname;
    public HallView(String newhallname) {
        hallname = newhallname;
        hallviewframe = new JFrame("Hall View");
        JMenuBar hallmenu = new JMenuBar();
        JMenu tomenu = new JMenu("return to menu");
        tomenu.addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {
                hallviewframe.setVisible(false);
            }

            @Override
            public void mousePressed(MouseEvent e) {

            }

            @Override
            public void mouseReleased(MouseEvent e) {

            }

            @Override
            public void mouseEntered(MouseEvent e) {

            }

            @Override
            public void mouseExited(MouseEvent e) {

            }
        });
        hallmenu.add(tomenu);
        HallPanel hallPanel = new HallPanel(hallname);
        hallPanel.setBounds(0, 0, 500, 300);


        JLabel NameLabel = new JLabel("Hall Name: Test1");
        NameLabel.setFont(new Font("Hall Name: Test1",1,30));
        NameLabel.setBounds(800,0,300,60);
        hallviewframe.add(NameLabel);

        JLabel AddLabel = new JLabel("Hall Address: AAA");
        AddLabel.setFont(new Font("Hall Address: AAA",1,30));
        AddLabel.setBounds(800,100,300,60);
        hallviewframe.add(AddLabel);

        JLabel PriceLabel = new JLabel("Hall Price: 999");
        PriceLabel.setFont(new Font("Hall Price: 999",1,30));
        PriceLabel.setBounds(800,200,300,60);
        hallviewframe.add(PriceLabel);

        JLabel DesLabel = new JLabel("Hall Description: aaaaaaaaaaaa");
        DesLabel.setFont(new Font("Hall Description: aaaaaaaaaaaa",1,30));
        DesLabel.setBounds(800,300,600,60);
        hallviewframe.add(DesLabel);


        //add Button
        Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
        int width = dim.getSize().width;
        int height = dim.getSize().height;
        int w = 150;
        int h = 60;
        int x = (width-w)/2;
        int y = (height-h)-130;
        JButton request_quo = new JButton("Request Quotation");
        request_quo.setBounds(x-100,y,150,60);
        request_quo.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JDialog conditiondialog = new JDialog();
                conditiondialog.setTitle("Enter your requirements");
                conditiondialog.setSize(350, 300);
                JPanel conditionpanel = new JPanel();
                conditionpanel.setLayout(null);
                JLabel HallNameLabel = new JLabel("Hall Name:");
                HallNameLabel.setBounds(50,30,80,25);
                conditionpanel.add(HallNameLabel);
                JTextField HallNameText = new JTextField(10);
                HallNameText.setBounds(160,30,80,25);
                HallNameText.setText("Test1");
                HallNameText.setEditable(false);
                conditionpanel.add(HallNameText);

                JLabel TypeLabel = new JLabel("Event Type:");
                TypeLabel.setBounds(50,80,80,25);
                conditionpanel.add(TypeLabel);

                JComboBox TypeComboBox = new JComboBox();
                TypeComboBox.setBounds(160,80,120,25);
                TypeComboBox.addItem("Please Choose");
                TypeComboBox.addItem("Wedding ceremony");
                TypeComboBox.addItem("Wedding ceremony");
                TypeComboBox.addItem("Birthday");
                TypeComboBox.addItem("Anniversary");
                conditionpanel.add(TypeComboBox);

                JLabel GuestNumLabel = new JLabel("Guests Number:");
                GuestNumLabel.setBounds(50,130,110,25);
                conditionpanel.add(GuestNumLabel);
                JTextField GuestNumText = new JTextField(10);
                GuestNumText.setBounds(160,130,80,25);
                conditionpanel.add(GuestNumText);
                conditiondialog.add(conditionpanel);

                JLabel DateLabel = new JLabel("Date:");
                DateLabel.setBounds(50,180,80,25);
                conditionpanel.add(DateLabel);

                JTextField DateText = new JTextField(10);
                DateText.setBounds(160,180,90,25);
                conditionpanel.add(DateText);


                //set Button
                JButton request = new JButton("Request quotation");
                request.setBounds(100,225,150,35);
                request.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        conditiondialog.setVisible(false);
                        JDialog quotationdialog = new JDialog();
                        quotationdialog.setTitle("Quotation");
                        quotationdialog.setSize(350, 300);
                        JPanel quotationpanel = new JPanel();
                        quotationpanel.setLayout(null);
                        JLabel NameLabel = new JLabel("Hall Name:");
                        NameLabel.setBounds(70,30,80,25);
                        quotationpanel.add(NameLabel);
                        JTextField NameText = new JTextField(10);
                        NameText.setBounds(180,30,80,25);
                        NameText.setText("Test1");
                        NameText.setEditable(false);
                        quotationpanel.add(NameText);

                        JLabel PriceLabel = new JLabel("Price:");
                        PriceLabel.setBounds(70,70,80,25);
                        quotationpanel.add(PriceLabel);
                        JTextField PriceText = new JTextField(10);
                        PriceText.setBounds(180,70,80,25);
                        PriceText.setText("999");
                        PriceText.setEditable(false);
                        quotationpanel.add(PriceText);

                        JLabel DiscountLabel = new JLabel("Discount:");
                        DiscountLabel.setBounds(70,110,80,25);
                        quotationpanel.add(DiscountLabel);
                        JTextField DiscountText = new JTextField(10);
                        DiscountText.setBounds(180,110,80,25);
                        DiscountText.setText("-99");
                        DiscountText.setEditable(false);
                        quotationpanel.add(DiscountText);

                        JLabel TotalLabel = new JLabel("Total Price:");
                        TotalLabel.setBounds(70,150,80,25);
                        quotationpanel.add(TotalLabel);
                        JTextField TotalText = new JTextField(10);
                        TotalText.setBounds(180,150,80,25);
                        TotalText.setText("900");
                        TotalText.setEditable(false);
                        quotationpanel.add(TotalText);

                        JButton confirm = new JButton("confirm");
                        confirm.setBounds(120,210,90,25);
                        confirm.addActionListener(new ActionListener() {
                            @Override
                            public void actionPerformed(ActionEvent e) {
                                quotationdialog.setVisible(false);
                            }
                        });
                        quotationpanel.add(confirm);

                        quotationdialog.add(quotationpanel);

                        Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
                        int w =  quotationdialog.getSize().width;
                        int h =  quotationdialog.getSize().height;
                        int x = (dim.width-w)/2;
                        int y = (dim.height-h)/2;
                        quotationdialog.setLocation(x, y-100);
                        quotationdialog.setVisible(true);
                    }
                });
                conditionpanel.add(request);
                conditiondialog.add(conditionpanel);
//set the location of logindialog in the center of screen
                Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
                int w =  conditiondialog.getSize().width;
                int h =  conditiondialog.getSize().height;
                int x = (dim.width-w)/2;
                int y = (dim.height-h)/2;
                conditiondialog.setLocation(x, y-100);
                conditiondialog.setVisible(true);
            }
        });
        JButton book = new JButton("Book");
        book.setBounds(x+100,y,150,60);
        book.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JDialog bookdialog = new JDialog();
                bookdialog.setTitle("Book");
                bookdialog.setSize(350,300);
                JPanel bookpanel = new JPanel();
                bookpanel.setLayout(null);

                JLabel BSBLabel = new JLabel("BSB Number:");
                BSBLabel.setBounds(70,30,110,25);
                bookpanel.add(BSBLabel);

                JTextField BSBText = new JTextField();
                BSBText.setBounds(180,30,110,25);
                bookpanel.add(BSBText);

                JLabel CVVLabel = new JLabel("CVV Number:");
                CVVLabel.setBounds(70,80,80,25);
                bookpanel.add(CVVLabel);

                JTextField CVVText = new JTextField();
                CVVText.setBounds(180,80,110,25);
                bookpanel.add(CVVText);

                JLabel ExpiredLabel = new JLabel("Expired Date:");
                ExpiredLabel.setBounds(70,130,110,25);
                bookpanel.add(ExpiredLabel);

                JTextField ExpiredText = new JTextField();
                ExpiredText.setBounds(180,130,110,25);
                bookpanel.add(ExpiredText);

                JButton book = new JButton("Book");
                book.setBounds(120,210,90,25);
                book.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        bookdialog.setVisible(false);
                        JDialog suredialog = new JDialog();
                        suredialog.setTitle("Are you sure?");
                        suredialog.setSize(300,200);

                        JPanel surepanel = new JPanel();
                        surepanel.setLayout(null);

                        JLabel surelabel = new JLabel("Are you sure you want to book?");
                        surelabel.setBounds(50,10,200,80);
                        surepanel.add(surelabel);

                        JButton yesbutton = new JButton("Yes");
                        yesbutton.setBounds(50,100,80,25);
                        yesbutton.addActionListener(new ActionListener() {
                            @Override
                            public void actionPerformed(ActionEvent e) {
                                suredialog.setVisible(false);
                                JOptionPane.showMessageDialog(bookdialog,"successful booking!");
                            }
                        });
                        JButton nobutton = new JButton("No");
                        nobutton.setBounds(170,100,80,25);
                        nobutton.addActionListener(new ActionListener() {
                            @Override
                            public void actionPerformed(ActionEvent e) {
                                suredialog.setVisible(false);
                            }
                        });
                        surepanel.add(yesbutton);
                        surepanel.add(nobutton);
                        int w =  suredialog.getSize().width;
                        int h =  suredialog.getSize().height;
                        int x = (dim.width-w)/2;
                        int y = (dim.height-h)/2;
                        suredialog.setLocation(x, y-100);
                        suredialog.setVisible(true);

                        suredialog.add(surepanel);

                    }
                });
                bookpanel.add(book);
                bookdialog.add(bookpanel);
                Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
                int w =  bookdialog.getSize().width;
                int h =  bookdialog.getSize().height;
                int x = (dim.width-w)/2;
                int y = (dim.height-h)/2;
                bookdialog.setLocation(x, y-100);
                bookdialog.setVisible(true);

            }
        });
        hallviewframe.setJMenuBar(hallmenu);
        hallviewframe.add(request_quo);
        hallviewframe.add(book);
        hallviewframe.add(hallPanel);
        hallviewframe.pack();
        hallviewframe.setVisible(true);
        hallviewframe.setExtendedState(JFrame.MAXIMIZED_BOTH);
    }

    public static void main(String[] args) {
        new HallView("Test1");
    }

}
class HallPanel extends JPanel {

    Image image = null;
    String hallname;
    public HallPanel(String newhallname){
        hallname = newhallname;
    }
    public void paint(Graphics g) {
        try {
            image = ImageIO.read(new File("src/images/"+hallname+".jpg"));
            g.drawImage(image, 0, 0, 550, 400, null);
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
}

