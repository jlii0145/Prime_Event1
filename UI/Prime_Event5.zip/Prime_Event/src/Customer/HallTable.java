package Customer;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.table.*;
public class HallTable {
    private static final long serialVersionUID = 1L;
    private JTable halltable = null;
    private DefaultTableModel hallmodel=null;
    public JScrollPane js=null ;
    public HallTable(){
       //hallmodel = new DefaultTableModel(3,3);
        Object[] columnNames = {"Hall Name","Address","Capacity","Preview","View"};
        Object[][] rowData = {
                {"Test1", "111", 80, 80, 240},
                {"Test2", "111", 80, 90, 240},
                {"Test3", "111", 70, 70, 210},
        };

    /*    hallmodel.setColumnIdentifiers(columnNames);
        hallmodel.addColumn(rowData);*/
        hallmodel = new DefaultTableModel(rowData,columnNames);
        halltable = new JTable(hallmodel);
        halltable.getColumnModel().getColumn(3).setCellEditor(new PreviewButton(halltable));
        halltable.getColumnModel().getColumn(3).setCellRenderer(new PreviewButton(halltable));
        halltable.getColumnModel().getColumn(4).setCellEditor(new ViewButton(halltable));
        halltable.getColumnModel().getColumn(4).setCellRenderer(new ViewButton(halltable));
        js = new JScrollPane(halltable);
        //js.setBounds(0,0,2000,2000);
        /*this.add(js);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setVisible(true);
        this.setSize(399, 300);
        this.setLocationRelativeTo(null);*/
    }
    public static void main(String[] args) {
// TODO Auto-generated method stub
        new HallTable();
    }
}

class ViewButton extends AbstractCellEditor implements TableCellRenderer,ActionListener, TableCellEditor{
    private static final long serialVersionUID = 1L;
    private JButton button =null;
    private JTable newtable;
    public ViewButton(JTable table){
        newtable = table;
        button = new JButton("view");
        button.addActionListener(this);
    }
    @Override
    public Object getCellEditorValue() {
// TODO Auto-generated method stub
        return null;
    }
    @Override
    public Component getTableCellRendererComponent(JTable table, Object value,
                                                   boolean isSelected, boolean hasFocus, int row, int column) {
// TODO Auto-generated method stub
        return button;
    }
    @Override
    public void actionPerformed(ActionEvent e) {
// TODO Auto-generated method stub
        int selectedrow = newtable.getSelectedRow();
        Object hallname_ob = newtable.getValueAt(selectedrow,0);
        String hallname = hallname_ob.toString();
        HallView hallview = new HallView(hallname);
        hallview.hallviewframe.setVisible(true);

    }
    @Override
    public Component getTableCellEditorComponent(JTable table, Object value,
                                                 boolean isSelected, int row, int column) {
// TODO Auto-generated method stub
        return button;
    }



}

class PreviewButton extends AbstractCellEditor implements TableCellRenderer,ActionListener, TableCellEditor{
    private static final long serialVersionUID = 1L;
    private JButton button =null;
    private JTable newtable;

    public PreviewButton(JTable table){
        newtable = table;
        button = new JButton("preview");
        button.addActionListener(this);
    }
    @Override
    public Object getCellEditorValue() {
// TODO Auto-generated method stub
        return null;
    }
    @Override
    public Component getTableCellRendererComponent(JTable table, Object value,
                                                   boolean isSelected, boolean hasFocus, int row, int column) {
// TODO Auto-generated method stub
        return button;
    }
    @Override
    public void actionPerformed(ActionEvent e) {
// TODO Auto-generated method stub
        JDialog picdialog = new JDialog();
        Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
        picdialog.setSize(700,500);
        int w = picdialog.getSize().width;
        int h = picdialog.getSize().height;
        int x = (dim.width-w)/2;
        int y = (dim.height-h)/2;
        picdialog.setLocation(x,y);
        int selectedrow = newtable.getSelectedRow();
        Object hallname_ob = newtable.getValueAt(selectedrow,0);
        String hallname = hallname_ob.toString();
        PreviewPanel pic =new PreviewPanel(hallname);
        picdialog.add(pic);
        picdialog.setVisible(true);
    }
    @Override
    public Component getTableCellEditorComponent(JTable table, Object value,
                                                 boolean isSelected, int row, int column) {
// TODO Auto-generated method stub
        return button;
    }
}
class PreviewPanel extends JPanel {

    Image image = null;
    private String hallname;
public PreviewPanel(String newhallname){
    hallname = newhallname;
}
    public void paint(Graphics g) {
        try {
            image = ImageIO.read(new File("src/images/"+hallname+".jpg"));
            g.drawImage(image, 0, 0, 550, 400, null);
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
}