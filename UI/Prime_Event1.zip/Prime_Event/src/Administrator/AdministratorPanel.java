package Administrator;


import Login_and_Register.LoginPanel;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;


public class AdministratorPanel {

    public static void ShowMenu()  {

        JFrame administratorframe = new JFrame("Administrator Panel");
        administratorframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        //set menu
        JMenuBar administratormenu = new JMenuBar();
        JMenu manage=new JMenu("manage");
        JMenuItem manageprofile = new JMenuItem("manage profile");
        JMenuItem managebooking = new JMenuItem("manage booking");
        administratormenu.add(manage);
        manage.add(manageprofile);
        manage.add(managebooking);

        JMenu logout = new JMenu("Log out");
        administratormenu.add(logout);
        logout.addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {
                administratorframe.setVisible(false);
                LoginPanel login = new LoginPanel();
                login.logindialog.setVisible(true);
            }

            @Override
            public void mousePressed(MouseEvent e) {

            }

            @Override
            public void mouseReleased(MouseEvent e) {

            }

            @Override
            public void mouseEntered(MouseEvent e) {

            }

            @Override
            public void mouseExited(MouseEvent e) {

            }
        });
      
       
        //set main panel
        JPanel mainPanel = new JPanel();
        administratorframe.setJMenuBar(administratormenu);
        administratorframe.pack();
        administratorframe.setVisible(true);
        administratorframe.setExtendedState(JFrame.MAXIMIZED_BOTH);

    }



    public static void main(String[] args) {
        ShowMenu();
    }

}


