package Owner;




import Login_and_Register.LoginPanel;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;


public class OwnerPanel {

    public static void ShowMenu()  {

        JFrame ownerframe = new JFrame("Owner Panel");
        ownerframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        //set menu
        JMenuBar ownermenu = new JMenuBar();
        JMenu manage=new JMenu("manage");
        JMenuItem manageprofile = new JMenuItem("manage profile");
        JMenuItem managebooking = new JMenuItem("manage booking");
        ownermenu.add(manage);
        manage.add(manageprofile);
        manage.add(managebooking);

        JMenu logout = new JMenu("Log out");
        ownermenu.add(logout);
        logout.addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {
                ownerframe.setVisible(false);
                LoginPanel login = new LoginPanel();
                login.logindialog.setVisible(true);
            }

            @Override
            public void mousePressed(MouseEvent e) {

            }

            @Override
            public void mouseReleased(MouseEvent e) {

            }

            @Override
            public void mouseEntered(MouseEvent e) {

            }

            @Override
            public void mouseExited(MouseEvent e) {

            }
        });


        //set main panel
        JPanel mainPanel = new JPanel();
        ownerframe.setJMenuBar(ownermenu);
        ownerframe.pack();
        ownerframe.setVisible(true);
        ownerframe.setExtendedState(JFrame.MAXIMIZED_BOTH);

    }



    public static void main(String[] args) {
        ShowMenu();
    }

}

