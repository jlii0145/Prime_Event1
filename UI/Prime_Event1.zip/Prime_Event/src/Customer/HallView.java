package Customer;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

public class HallView {
    public static JFrame hallviewframe;
    String hallname;
    public HallView(String newhallname) {
        hallname = newhallname;
        hallviewframe = new JFrame("Hall View");
        HallPanel hallPanel = new HallPanel(hallname);
        hallPanel.setBounds(0, 0, 500, 300);

        //add Button
        Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
        int width = dim.getSize().width;
        int height = dim.getSize().height;
        int w = 150;
        int h = 60;
        int x = (width-w)/2;
        int y = (height-h)-130;
        JButton request_quo = new JButton("Request Quotation");
        request_quo.setBounds(x-100,y,150,60);
        request_quo.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JDialog quotationdialog = new JDialog();
                quotationdialog.setTitle("Quotation");
                quotationdialog.setSize(350, 300);
                JPanel quotationpanel = new JPanel();
                quotationpanel.setLayout(null);
                JLabel HallNameLabel = new JLabel("Hall Name:");
                HallNameLabel.setBounds(50,30,80,25);
                quotationpanel.add(HallNameLabel);
                JTextField HallNameText = new JTextField(10);
                HallNameText.setBounds(160,30,80,25);
                HallNameText.setText("Test1");
                HallNameText.setEditable(false);
                quotationpanel.add(HallNameText);

                JLabel HallPriceLabel = new JLabel("Hall Price:");
                HallPriceLabel.setBounds(50,80,80,25);
                quotationpanel.add(HallPriceLabel);
                JTextField HallPriceText = new JTextField(10);
                HallPriceText.setBounds(160,80,80,25);
                HallPriceText.setText("999");
                HallPriceText.setEditable(false);
                quotationpanel.add(HallPriceText);
                quotationdialog.add(quotationpanel);
                quotationdialog.setVisible(true);

                //set Button
                JButton confirm = new JButton("confirm");
                confirm.setBounds(135,200,80,35);
                confirm.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        quotationdialog.setVisible(false);
                    }
                });
                quotationpanel.add(confirm);
//set the location of logindialog in the center of screen
                Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
                int w =  quotationdialog.getSize().width;
                int h =  quotationdialog.getSize().height;
                int x = (dim.width-w)/2;
                int y = (dim.height-h)/2;
                quotationdialog.setLocation(x, y-100);
                quotationdialog.setVisible(true);
            }
        });
        JButton book = new JButton("Book");
        book.setBounds(x+100,y,150,60);
        hallviewframe.add(request_quo);
        hallviewframe.add(book);
        hallviewframe.add(hallPanel);
        hallviewframe.pack();
        hallviewframe.setVisible(true);
        hallviewframe.setExtendedState(JFrame.MAXIMIZED_BOTH);
    }

    public static void main(String[] args) {
        new HallView("Test1");
    }
}
class HallPanel extends JPanel {

    Image image = null;
    String hallname;
    public HallPanel(String newhallname){
        hallname = newhallname;
    }
    public void paint(Graphics g) {
        try {
            image = ImageIO.read(new File("src/images/"+hallname+".jpg"));
            g.drawImage(image, 0, 0, 550, 400, null);
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
}

